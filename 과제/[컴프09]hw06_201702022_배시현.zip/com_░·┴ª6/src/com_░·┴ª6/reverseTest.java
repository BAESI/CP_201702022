package com_����6;
	import java.util.Scanner;
public class reverseTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		reverse nr = new reverse();
		
		String texta;
		
		System.out.print("���ڿ��� �Է��Ͻÿ�.");
		texta = input.next();
		
		nr.reverse(texta);
		
		
	}

}
