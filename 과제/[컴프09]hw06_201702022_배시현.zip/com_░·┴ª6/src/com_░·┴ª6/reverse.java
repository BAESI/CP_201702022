package com_����6;

public class reverse {
	private String text;
	
	public void reverse(String t) {
		text = t;
		
		for (int a = text.length() ; a > 0; a--) {
			System.out.print(text.charAt(a-1));

		}
		
	}
		
	
}	
