
public class Employee {
	private String Name;
	private String Number;
	private int Pay;

	public String getname() {
		return Name;
	}

	public void setname(String n) {
		Name = n;
	}

	public String getnumber() {
		return Number;
	}

	public void setnumber(String nu) {
		Number = nu;
	}

	public int getpay() {
		return Pay;
	}

	public void setpay(int p) {
		Pay = p;
	}

}
